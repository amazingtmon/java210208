package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo0511Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo0511Application.class, args);
	}

}
