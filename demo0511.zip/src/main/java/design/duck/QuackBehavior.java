package design.duck;

public interface QuackBehavior {
	
	public void quack();
}
